# My Personal Website



# Description 
<p>This application enables people to explore on the new drinks that are available and one can add a new drink when they discover it</p>
<p></p>

# sreenshot
<img src="images/Screenshot from 2024-05-05 21-35-42.png" alt="testimage">

# setup and installation
1. clone the repository.
2. Navigate to the project directory.
3. install the dependancies.
4. Access the website


# Technology used 

<p>HTML</p>
<P>CSS</p>
<P>JavaScript</p>

# Author information
written by @Glitch


# license
